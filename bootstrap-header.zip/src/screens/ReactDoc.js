import React from "react";

const ReactDoc = () => {
  return <div>ReactDoc</div>;
};

export default ReactDoc;
